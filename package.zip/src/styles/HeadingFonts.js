import styled from 'styled-components';

export const LoginSignupHeader = styled.p`
   color: #fff;
   font-size: 30px;
   font-weight: 400;
   
`;
