import React from 'react';

function HomePage() {
  return <div><h1>Hello this is home page</h1></div>;
}

export default HomePage;
